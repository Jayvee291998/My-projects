import numpy as np 
from neural_network7 import NeuralNetwork
import pickle
sizes = [16, 8, 2]
num_layers = len(sizes)
network = NeuralNetwork(sizes)

training_data_file = open("training_data.pickle", "rb")
training_data1 = pickle.load(training_data_file) 

data = training_data1[0]
labels = training_data1[1]
vectorized_data = [np.reshape(datum, (16, 1)) for datum in data]
vectorized_label = [np.reshape(label, (2,1)) for label in labels]
training_data = [(d,l) for d, l in zip(vectorized_data, vectorized_label)]

network.SGD(training_data[:30000], epochs = 5, learning_rate = 0.1, batch_size = 100, validation_data = training_data[30000:60000])
index = 60000
print(network.feedForward(data[index]))
print(labels[index])

with open("model.pickle", "wb") as file:
	pickle.dump(network, file)
