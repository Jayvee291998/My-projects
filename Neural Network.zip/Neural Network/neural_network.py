import numpy as np
import random

class NeuralNetwork():
	"""A neural network class"""

	def __init__(self, sizes):
		self.weigths = [np.random.sample((row, col)) for row, col in zip(sizes[1:], sizes[:-1])]
		self.biases = [np.random.sample((row)) for row in sizes[1:]]
		self.number_of_layer = len(sizes)

	def feedForward(self, data):
		activation = data;
		for w, b in zip(self.weigths, self.biases):
			z = np.matmul(w, activation) + b
			activation = self.sigmoid(z)
		return activation

	def backProp(self, data, label):
		nabla_b = [np.zeros((b.shape)) for b in self.biases]
		nabla_w = [np.zeros((w.shape)) for w in self.weigths]
		activation = data
		activations = [activation]
		input_errors = []
		for w, b in zip(self.weigths, self.biases):
			z = np.matmul(w, activation) + b
			activation = self.sigmoid(z)
			input_errors.append(z)
			activations.append(activation)
		
		delta = self.cost_prime(activations[-1], label)*self.sigmoid_prime(input_errors[-1])
		nabla_b[-1] = delta
		deltaT = np.array([delta]).transpose()
		activationT = np.array([activations[-2]])
		nabla_w[-1] = deltaT * activationT

		for l in range(2, self.number_of_layer):
			delta = np.matmul(self.weigths[-l + 1].transpose(), delta) * self.sigmoid_prime(input_errors[-l])
			nabla_b[-l] = delta
			deltaT = np.array([delta]).transpose()
			activationT = np.array([activations[-l - 1]])
			nabla_w[-l] = deltaT * activationT
		return (nabla_w, nabla_b)

	def SGD(self, data, labels, learning_rate = 0.1, epochs = 1):
		for i in range(epochs):
			for datum, label in zip(data, labels):
				nabla_w, nabla_b = self.backProp(datum, label)
				self.weigths = [w-(nw*learning_rate) for w, nw in zip(self.weigths, nabla_w)]
				self.biases = [b-(nb*learning_rate) for b, nb in zip(self.biases, nabla_b)]
			if i % 10000 == 0:
				print(i)

	def sigmoid(self, array):
		return (1 / (1 + np.exp(-1 * array)))

	def sigmoid_prime(self, array):
		return ((np.exp(-1 * array)) / ((1 + np.exp(-1 * array)) ** 2))

	def cost_prime(self, array, label):
		return 2 * (array - label)
