import gzip
import pickle 
import numpy as np 
from neural_network4 import NeuralNetwork 

def vectorized_labels(labels):
	vectorized_labels = []
	for label in labels:
		cur_label = np.zeros((10))
		cur_label[label] = 1.0
		vectorized_labels.append(cur_label)
	return vectorized_labels


file = gzip.open("mnist.pkl-1.gz", "rb")
training_data, validation_data, test_data = pickle.load(file, encoding = "latin1")
file.close()


training_images = training_data[0]
vectorized_training_labels = vectorized_labels(training_data[1])

training_data1 = [(image, label) for image, label in zip(training_images, vectorized_training_labels)]

validation_images = validation_data[0]
vectorized_validation_labels = vectorized_labels(validation_data[1])

validation_data1 = [(image, label) for image, label in zip(validation_images, vectorized_validation_labels)]
sizes = [784, 32, 10]
network = NeuralNetwork(sizes)

network.SGD(training_data1, epochs = 1, learning_rate = 0.1, batch_size = 50, validation_data = validation_data1)