import numpy as np 
import pickle
"""A method that just generate a string that repeats the given char for length"""
def gen(char, length):
	n = ""
	for i in range(length):
		n = n +char
	return n
"""A method that gives the binary string representation of a integer"""
def binaryRep(num):
	binary_rep = []
	max_len = len(bin(num-1))-2
	for i in range(num):
		cur_bin = bin(i)[2:]
		cur_bin_len = len(cur_bin)
		gap = max_len - cur_bin_len
		binary = gen("0", gap) + cur_bin
		binary_rep.append(binary)
	return binary_rep

"""A method that will return the a list of np.array whose contents are the individual bits of the binary"""
def binaryToArray(binary_rep):
	max_len = len(binary_rep[-1])
	binary_array = []
	for binary in binary_rep:
		cur_array = np.zeros((max_len), dtype = "int8")
		for i in range(len(binary)):
			if binary[i] == "1":
				cur_array[i] = 1
		binary_array.append(cur_array)
	return binary_array

"""A method that converts the binary representation to its booalean representation"""
def binaryToBool(binary_rep):
	binary_bool_list = []
	bin_len = len(binary_rep[-1])
	for binary in binary_rep:
		cur_bin = [False]*bin_len
		for i in range(len(binary)):
			if binary[i] == "1":
				cur_bin[i] = True
		binary_bool_list.append(cur_bin)
	return binary_bool_list

def sixteenBitLogic(binary_bool_list):
	binary_results = []
	for binary_bool in binary_bool_list:
		cur_result = np.zeros((2))
		bit1 = binary_bool[0] or binary_bool[1] or binary_bool[2] or binary_bool[3]
		bit2 = binary_bool[4] and binary_bool[5] and binary_bool[6] and binary_bool[7]
		bit3 = binary_bool[8] or binary_bool[9] or binary_bool[10] or binary_bool[11]
		bit4 = binary_bool[12] and binary_bool[13] and binary_bool[14] and binary_bool[15]

		bit5 = bit1 or bit2
		bit6 = bit3 and bit4

		bit7 = not(bit5 and bit6)
		if bit7:
			cur_result[0] = 1
		else:
			cur_result[1] = 1
		binary_results.append(cur_result)
	return binary_results



binary_rep = binaryRep(2**16)
binary_array = binaryToArray(binary_rep)
binary_bool_list = binaryToBool(binary_rep)
logic = sixteenBitLogic(binary_bool_list)
ex = 65535
print(binary_array[ex])
print(binary_bool_list[ex])
if logic[ex][0] == 1:
	print("True")
else:
	print("False")
training_data = (binary_array, logic)
with open("training_data.pickle", "wb") as file:
	pickle.dump(training_data, file)

#for binary in binary_rep:
#	print(binary)
