import numpy as np 
from neural_network3 import NeuralNetwork
import pickle
sizes = [4, 2, 2]
num_layers = len(sizes)
network = NeuralNetwork(sizes)




data1 = np.array([0,0,0,0])
data2 = np.array([0,0,0,1])
data3 = np.array([0,0,1,0])
data4 = np.array([0,0,1,1])
data5 = np.array([0,1,0,0])
data6 = np.array([0,1,0,1])
data7 = np.array([0,1,1,0])
data8 = np.array([0,1,1,1])
data9 = np.array([1,0,0,0])
data10 = np.array([1,0,0,1])
data11 = np.array([1,0,1,0])
data12 = np.array([1,0,1,1])
data13 = np.array([1,1,0,0])
data14 = np.array([1,1,0,1])
data15 = np.array([1,1,1,0])
data16 = np.array([1,1,1,1])


label0 = np.array([1,0])
label1 = np.array([0,1])


data = [data1, data2, data3, data4, data5, data6, data7, data8, data9, data10, data11, data12, data13, data14, data15, data16]
labels = [label0, label1, label1, label0, label1, label0, label0, label0, label1, label0, label0, label0, label0, label0, label0, label0]
training_data = [(d,l) for d, l in zip(data, labels)]
network.SGD(training_data[:12], epochs = 10000, learning_rate = 0.5, batch_size = 1)

with open("model_network.pickle", "wb") as file:
	pickle.dump(network, file)

prediction = []
for i in range(12,len(data)):
	prediction.append(network.feedForward(data[i]))

for i in range(len(prediction)):
	print(data[12 + i])
	print(prediction[i])

#print(network.feedForward(np.array([1,0,0,0])))

#print(len(bin(1)))
"""ac = network.feedForward(data)
nabla_w, nabla_b = network.backProp(data, label)

for i in range(num_layers-1):
	print("Layer ", i)
	print()
	print("Nabla w: ")
	print(nabla_w[i])
	print()
	print("Nabla b: ")
	print(nabla_b[i])
	print()"""

#print(ac)
#print(acc)