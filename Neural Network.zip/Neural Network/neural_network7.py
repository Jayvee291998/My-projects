import numpy as np
import random

class NeuralNetwork():
	"""A neural network class"""

	def __init__(self, sizes):
		self.biases = [np.random.randn(y, 1) for y in sizes[1:]]
		self.weigths = [np.random.randn(y, x) for x, y in zip(sizes[:-1], sizes[1:])]
		self.number_of_layer = len(sizes)

	def feedForward(self, data):
		activation = data;
		for w, b in zip(self.weigths, self.biases):
			z = np.matmul(w, activation) + b
			activation = self.sigmoid(z)
		return activation

	def backProp(self, data, label):
		nabla_b = [np.zeros((b.shape)) for b in self.biases]
		nabla_w = [np.zeros((w.shape)) for w in self.weigths]
		activation = data
		activations = [activation]
		input_errors = []
		for w, b in zip(self.weigths, self.biases):
			z = np.matmul(w, activation) + b
			activation = self.sigmoid(z)
			input_errors.append(z)
			activations.append(activation)
		
		delta = self.cost_prime(activations[-1], label)*self.sigmoid_prime(input_errors[-1])
		nabla_b[-1] = delta

		nabla_w[-1] = np.dot(delta, activations[-2].transpose())

		for l in range(2, self.number_of_layer):
			delta = np.matmul(self.weigths[-l + 1].transpose(), delta) * self.sigmoid_prime(input_errors[-l])
			nabla_b[-l] = delta
			nabla_w[-l] = np.dot(delta, activations[-l-1].transpose())
		return (nabla_w, nabla_b)

	def SGD(self, training_data, learning_rate = 0.1, epochs = 1, batch_size = 10, validation_data = None):
		rem = (int)(len(training_data) % batch_size)
		n = (int)(len(training_data) / batch_size)
		batches = [training_data[batch_size*(i):batch_size*(i+1)] for i in range(n)]
		if validation_data:
			validation_data_len = len(validation_data)
		if rem != 0:
			batches.append(training_data[batch_size*(n-1):(batch_size*(n-1)+rem)])
		for i in range(epochs):
			random.shuffle(batches)
			for batch in batches:
				self.train_mini_batch(batch, learning_rate)
			if validation_data:
				print("Epoch ", i, ": ", self.evaluate(validation_data), "/", validation_data_len)
			else:
				print("Epoch ",i,": finished")


	def train_mini_batch(self, batch_training_data, learning_rate = 0.1):
		total_nabla_w = [np.zeros((w.shape)) for w in self.weigths]
		total_nabla_b = [np.zeros((b.shape)) for b in self.biases]
		n = len(batch_training_data)
		for datum, label in batch_training_data:
			nabla_w, nabla_b = self.backProp(datum, label)
			total_nabla_w = [tnw + nw for tnw, nw in zip(total_nabla_w, nabla_w)]
			total_nabla_b = [tnb + nb for tnb, nb in zip(total_nabla_b, nabla_b)]
		self.weigths = [w-((tnw/n)*learning_rate) for w, tnw in zip(self.weigths, total_nabla_w)]
		self.biases = [b-((tnb/n)*learning_rate) for b, tnb in zip(self.biases, total_nabla_b)]

	def evaluate(self, data):
		score = 0
		for datum, label in data:
			prediction = self.feedForward(datum)
			if np.argmax(prediction) == np.argmax(label):
				score += 1
		return score

	def sigmoid(self, array):
		return (1 / (1 + np.exp(-1 * array)))

	def sigmoid_prime(self, array):
		return self.sigmoid(array) * (1 - self.sigmoid(array))

	def cost_prime(self, array, label):
		return 2 * (array - label)
