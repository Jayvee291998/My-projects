import gzip
import pickle 
import numpy as np 
from neural_network7 import NeuralNetwork 

def vectorized_labels(labels):
	vectorized_labels = []
	for label in labels:
		cur_label = np.zeros((10,1))
		cur_label[label] = 1.0
		vectorized_labels.append(cur_label)
	return vectorized_labels


file = gzip.open("mnist.pkl-1.gz", "rb")
training_data, validation_data, test_data = pickle.load(file, encoding = "latin1")
file.close()


#training_images = training_data[0]
training_images = [np.reshape(image, (784, 1)) for image in training_data[0]]
vectorized_training_labels = vectorized_labels(training_data[1])

training_data1 = [(image, label) for image, label in zip(training_images, vectorized_training_labels)]

#validation_images = validation_data[0]
validation_images = [np.reshape(image, (784, 1)) for image in validation_data[0]]
vectorized_validation_labels = vectorized_labels(validation_data[1])

validation_data1 = [(image, label) for image, label in zip(validation_images, vectorized_validation_labels)]
sizes = [784, 32, 10]
#network = NeuralNetwork(sizes)

#network.SGD(training_data1, epochs = 30, learning_rate = 3, batch_size = 10, validation_data = validation_data1)
file = open("model.pickle", "rb")
network = pickle.load(file)
res = network.feedForward(training_images[0])


predictions = [network.feedForward(datum) for datum in validation_images]

print(vectorized_validation_labels[5795])
print(predictions[5795])


print(np.argmax(res))
print(np.argmax(vectorized_training_labels[0]))

""""with open("model.pickle", "wb") as file:
	pickle.dump(network, file)"""
