import numpy as np
import random

class NeuralNetwork():
	"""A neural network class"""

	def __init__(self, sizes):
		self.weigths = [np.random.sample((row, col)) for row, col in zip(sizes[1:], sizes[:-1])]
		self.biases = [np.random.sample((row)) for row in sizes[1:]]
		self.number_of_layer = len(sizes)

	def feedForward(self, data):
		activation = data;
		for w, b in zip(self.weigths, self.biases):
			z = np.matmul(w, activation) + b
			activation = self.sigmoid(z)
		return activation

	def backProp(self, data, label):
		nabla_b = [np.zeros((b.shape)) for b in self.biases]
		nabla_w = [np.zeros((w.shape)) for w in self.weigths]
		activation = data
		activations = [activation]
		input_errors = []
		for w, b in zip(self.weigths, self.biases):
			z = np.matmul(w, activation) + b
			activation = self.sigmoid(z)
			input_errors.append(z)
			activations.append(activation)
		
		delta = self.cost_prime(activations[-1], label)*self.sigmoid_prime(input_errors[-1])
		nabla_b[-1] = delta
		deltaT = np.array([delta]).transpose()
		activationT = np.array([activations[-2]])
		nabla_w[-1] = deltaT * activationT

		for l in range(2, self.number_of_layer):
			delta = np.matmul(self.weigths[-l + 1].transpose(), delta) * self.sigmoid_prime(input_errors[-l])
			nabla_b[-l] = delta
			deltaT = np.array([delta]).transpose()
			activationT = np.array([activations[-l - 1]])
			nabla_w[-l] = deltaT * activationT
		return (nabla_w, nabla_b)

	def SGD(self, training_data, learning_rate = 0.1, epochs = 1, batch_size = 10):
		
		batches = [training_data[]]
		for i in range(epochs):
			random.shuffle(training_data)
			self.train_mini_batch(training_data[:5])
			self.train_mini_batch(training_data[5:10])
			self.train_mini_batch(training_data[10:12])
			if i % 5000 == 0:
				print(i)
		print("finished")

	def train_mini_batch(self, batch_training_data, learning_rate = 0.1):
		total_nabla_w = [np.zeros((w.shape)) for w in self.weigths]
		total_nabla_b = [np.zeros((b.shape)) for b in self.biases]
		n = len(batch_training_data)
		for datum, label in batch_training_data:
			nabla_w, nabla_b = self.backProp(datum, label)
			total_nabla_w = [tnw + nw for tnw, nw in zip(total_nabla_w, nabla_w)]
			total_nabla_b = [tnb + nb for tnb, nb in zip(total_nabla_b, nabla_b)]

		self.weigths = [w-((tnw/n)*learning_rate) for w, tnw in zip(self.weigths, total_nabla_w)]
		self.biases = [b-((tnb/n)*learning_rate) for b, tnb in zip(self.biases, total_nabla_b)]

	def sigmoid(self, array):
		return (1 / (1 + np.exp(-1 * array)))

	def sigmoid_prime(self, array):
		return ((np.exp(-1 * array)) / ((1 + np.exp(-1 * array)) ** 2))

	def cost_prime(self, array, label):
		return 2 * (array - label)
