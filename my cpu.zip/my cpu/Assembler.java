import java.util.Scanner;
import java.util.ArrayList;

public class Assembler
{
	private int numberOfRegisters = 15;
	private String[] registers = new String[numberOfRegisters];
	private String[] registerAdr = new String[numberOfRegisters];
	private int numberOfOperations = 41;
	private String[] operations	 = {"mov", "movr,#", "movr,[r]#", "mov[r],r", "movr,[r]", "add", "sub", "mul", "div", "and", "or", "nor", "xor", "neg",
			"not", "llsr,#", "lrsr,#", "arsr,#", "inc", "dec", "inc[r]", "dec[r]", "jmp", "je", "jne", "ja", "jna", "jb", "jnb",
			"jz", "jnz", "jmPos", "jmNeg", "cmp", "mov[r]#,r", "strcarry", "strresult", "addna", "subna", "mulna", "divna"
		};
	private String[] operationsCode = {
			"00", "00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "0a", "0b", "0c", "0d", "0f", "10", "11", "12",
			"13", "14", "15", "1710", "1720", "1730", "1740", "1750", "1770", "1780", "1790", "17a0", "17b0", "17c0", "18", "19",
			"1a50", "1a60", "1b", "1c", "1d", "1e"
		};

	

	public Assembler()
	{
		//initialize the registers
		for(int i=0; i<numberOfRegisters; i++)
		{
			registers[i] = "reg"+(i+1);
			registerAdr[i] = Integer.toHexString(i+1);
		}
	}

	/**
		A function that parse register arguments an returns an hex address for that register
		@param reg 
		@return adr
	*/

	public String parseReg(String reg)
	{
		String adr = "";
		for(int i = 0; i < numberOfRegisters; i++)
		{
			if(reg.equals(registers[i]))
			{
				adr = registerAdr[i];
			}
		}
		return adr;
	}

	/**
		A method that parse the operations
		@param op the operation
		@param opCode
	*/
	public String parseOp(String op)
	{
		String opCode = "";
		for(int i=0; i < numberOfOperations; i++)
		{
			if(op.equals(operations[i]))
			{
				opCode = operationsCode[i];
			}
		}
		return opCode;
	}

	/**
		A method that assembles the assembly code
		@param assemblyCodes
		@return machineCodes
	*/
	public ArrayList<String> assemble(ArrayList<String> assemblyCodes)
	{
		ArrayList<String> machineCodes = new ArrayList<String>();
		for(String line : assemblyCodes)
		{
			Scanner lineScanner = new Scanner(line);
			String op = lineScanner.next();
			String arg1 = lineScanner.next();
			String arg2 = lineScanner.next();
			String machine = parseOp(op) + parseReg(arg1) + parseReg(arg2);
			machineCodes.add(machine);		
		}
		return machineCodes;
	}
}