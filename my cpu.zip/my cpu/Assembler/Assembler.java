import java.util.Scanner;
import java.util.ArrayList;

public class Assembler
{
	private int numberOfRegisters = 15;
	private String[] registers = new String[numberOfRegisters];
	private String[] registerAdr = new String[numberOfRegisters];
	private int numberOfOperations = 41;
	private String[] operations	 = {"mov", "movr,#", "movr,[r]#", "mov[r],r", "movr,[r]", "add", "sub", "mul", "div", "and", "or", "nor", "xor", "neg",
			"not", "llsr,#", "lrsr,#", "arsr,#", "inc", "dec", "inc[r]", "dec[r]", "jmp", "je", "jne", "ja", "jna", "jb", "jnb",
			"jz", "jnz", "jmPos", "jmNeg", "cmp", "mov[r]#,r", "strcarry", "strresult", "addna", "subna", "mulna", "divna"
		};
	private String[] operationsCode = {
			"00", "00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "0a", "0b", "0c", "0d", "0f", "10", "11", "12",
			"13", "14", "15", "1710", "1720", "1730", "1740", "1750", "1770", "1780", "1790", "17a0", "17b0", "17c0", "18", "19",
			"1a5", "1a6", "1b", "1c", "1d", "1e"
		};
	private String[] jumpIns = {"jmp", "je", "jne", "ja", "jna", "jb", "jnb","jz", "jnz", "jmPos", "jmNeg"};

	private String[] assemblerIns = {"setLabel", "useLabel", ""};

	

	public Assembler()
	{
		//initialize the registers
		for(int i=0; i<numberOfRegisters; i++)
		{
			registers[i] = "reg"+(i+1);
			registerAdr[i] = Integer.toHexString(i+1);
		}
	}

	/**
		A function that parse register arguments an returns an hex address for that register
		@param reg 
		@return adr
	*/

	public String parseReg(String reg)
	{
		String adr = "";
		for(int i = 0; i < numberOfRegisters; i++)
		{
			if(reg.equals(registers[i]))
			{
				adr = registerAdr[i];
			}
		}
		return adr;
	}

	/**
		A method that parse the operations
		@param op the operation
		@param opCode
	*/
	public String parseOp(String op)
	{
		String opCode = "";
		for(int i=0; i < numberOfOperations; i++)
		{
			if(op.equals(operations[i]))
			{
				opCode = operationsCode[i];
			}
		}
		return opCode;
	}

	/**
		A method that assembles the assembly code
		@param assemblyCodes
		@return machineCodes
	*/
	public ArrayList<String> assemble(ArrayList<String> assemblyCodes)
	{
		ArrayList<String> machineCodes = new ArrayList<String>();
		
		for(String line : assemblyCodes)
		{
			ArrayList<String> arguments = new ArrayList<String>();
			Scanner lineScanner = new Scanner(line);
			while(lineScanner.hasNext())
			{
				String arg = lineScanner.next();
				arguments.add(arg);
			}
			machineCodes.add(parseArgs(arguments));	
		}
		return machineCodes;
	}
	/**
		A method that parse the assembly code
		@param arguments
		@return machinecode
	*/
	public String parseArgs(ArrayList<String> arguments)
	{
		int argsSize = arguments.size();
		String machinecode = "";
		if(argsSize == 2)
		{
			String op = arguments.get(0);
			String arg1 = arguments.get(1);
			if("jmp".equals(op) || "je".equals(op) || "jne".equals(op) || "ja".equals(op) || "jna".equals(op) || "jb".equals(op) || "jnb".equals(op) || "jz".equals(op) || "jnz".equals(op) || "jmPos".equals(op) || "jmNeg".equals(op))
			{
				machinecode = parseOp(op) + " " + arg1;
			}
			else
			{
				machinecode = parseOp(op) + parseReg(arg1);
			}
		}
		else if(argsSize == 3)
		{
			String op = arguments.get(0);
			String arg1 = arguments.get(1);
			String arg2 = arguments.get(2);
			if("llsr,#".equals(op) || "lrsr,#".equals(op) || "arsr,#".equals(op))
			{
				machinecode = parseOp(op) + parseReg(arg1) + arg2;
			}
			else
			{
				machinecode = parseOp(op) + parseReg(arg1) + parseReg(arg2);
			}
		}
		else if(argsSize == 4)
		{
			String op = arguments.get(0);
			String arg1 = arguments.get(1);
			String arg2 = arguments.get(2);
			String immediateValue = arguments.get(3);
			machinecode = parseOp(op) + parseReg(arg1) + parseReg(arg2) + " " + immediateValue;
		}
		return machinecode;
	}
}