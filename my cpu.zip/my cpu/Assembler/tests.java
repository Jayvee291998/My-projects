import java.util.Scanner;
public class tests
{
	public static void main(String[] args) 
	{
		int numberOfOperations = 39;
		String[] operations = {
			"movr,[r]#",
			"mov[r],r",
			"movr,[r]",
			"add",
			"sub",
			"mul",
			"div",
			"and",
			"or",
			"nor",
			"xor",
			"neg",
			"not",
			"llsr,#",
			"lrsr,#",
			"arsr,#",
			"inc",
			"dec",
			"inc[r]",
			"dec[r]",
			"jmp",
			"je",
			"jne",
			"ja",
			"jna",
			"jb",
			"jnb",
			"jz",
			"jnz",
			"jmPos",
			"jmNeg",
			"cmp",
			"mov[r]#,r",
			"strcarry",
			"strresult",
			"addna",
			"subna",
			"mulna",
			"divna"
		};

		for(String op : operations)
		{
			System.out.println(op);
		}
	}
}