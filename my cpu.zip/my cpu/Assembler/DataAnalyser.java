import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.NoSuchElementException;
import java.util.ArrayList;


public class DataAnalyser
{
	public ArrayList<String> getCode() 
	{
		Scanner in = new Scanner(System.in);
		ArrayList<String> assemblyCodes = new ArrayList<String>();

		//keep trying until there are no more exception
		boolean done = false;
		while(!done)
		{
			try
			{
				System.out.print("Please enter the file name: ");
				String filename = in.next();

				assemblyCodes = readFile(filename);

				done = true;
			}
			catch(FileNotFoundException exception)
			{
				System.out.println("File not found.");
			}
			catch(NoSuchElementException exception)
			{
				System.out.println("File contents invalid.");
			}
			catch(IOException exception)
			{
				exception.printStackTrace();
			}
		}
		return assemblyCodes;
	}

	/**
		Opens a file and reads a data set
		@param filename the name of the file holding the data
		@return the data in the file
	*/
	public ArrayList<String> readFile(String filename) throws IOException
	{
		File inFile = new File(filename);
		Scanner in = new Scanner(inFile);
		try
		{
			return readData(in);
		}
		finally
		{
			in.close();
		}
	}

	/**
		Reads a data set
		@param in the scanner that scans the data
		@return the data set
	*/
	public ArrayList<String> readData(Scanner in) throws IOException
	{
		ArrayList<String> assemblyCode = new ArrayList<String>();

		while(in.hasNextLine())
		{
			String line = in.nextLine();
			assemblyCode.add(line);
		}
		return assemblyCode;
	}

	/**
		A method that writes the data in an arraylist to a textfile
		@param outputFilename the name of the output file
		@param data the arraylist that contains the data to be written
	*/
	public void writeToOutput(String outputFilename, ArrayList<String> data) throws FileNotFoundException
	{
		PrintWriter out = new PrintWriter(outputFilename);
		for(String line : data)
		{
			out.printf("%s\n",line);
		}
		out.close();
	}
}