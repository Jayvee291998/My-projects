import java.io.File;
import java.io.PrintWriter;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.ArrayList;

public class test
{
	/*
		This program reads a textfile with assembly code and outputs a textfile with the corresponding machinecode
	*/
	public static void main(String[] args) throws FileNotFoundException
	{
		DataAnalyser codes  = new DataAnalyser();
		Assembler assemble = new Assembler();

		ArrayList<String> lines = new ArrayList<String>();
		ArrayList<String> mcode = new ArrayList<String>();
		lines = codes.getCode();
		printStringArrayList(lines);
		mcode = assemble.assemble(lines);
		printStringArrayList(mcode);
		codes.writeToOutput("out.txt", mcode);
	}
	/**
		A method that prints the contents of an string arraylist
		@param arraylist the arraylist that will be printed
	*/
	public static void printStringArrayList(ArrayList<String> arraylist)
	{
		for(String item : arraylist)
		{
			System.out.println(item);
		}
	}
}