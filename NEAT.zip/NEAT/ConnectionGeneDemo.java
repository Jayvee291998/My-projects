public class ConnectionGeneDemo
{
	public static void main(String[] args) 
	{
		ConnectionGene cg = new ConnectionGene(1, 2, 0.12, true, 1);
		cg.toggleEnbl();
		System.out.println(cg);	
	}
}