public class ConnectionGene
{
	private final int in; // from the input node
	private final int out; // to the output node
	private double weigth; // weigth of the connection between the two node gene
	private boolean enableBit; // wether the conncetion gene is active or not
	private final int innov; //the innovation number of the connection gene

	/**	
		Contructs the object with the input node, output node, weigth, enableBit ,and innovation number.
		@param in
		@param out
		@param weigth
		@param enableBit
		@param innov
	*/
	public ConnectionGene(int in, int out, double weigth, boolean enableBit, int innov)
	{
		this.in = in;
		this.out = out;
		this.weigth = weigth;
		this.enableBit = enableBit;
		this.innov = innov;
	}

	/**
		A method that sets the weigth of the gene
		@param newWeigth
	*/
	public void setWeigth(double newWeigth)
	{
		this.weigth = newWeigth;
	}

	/**
		sets the enable bit of the connection gene
		@param value
	*/
	public void setEnbl(boolean value)
	{
		this.enableBit = value;
	}

	/**
		A method that toggles the enable bit
	*/
	public void toggleEnbl()
	{
		if(this.enableBit)
		{
			this.enableBit = false;
		}
		else
		{
			this.enableBit = true;
		}
	}
	
	/**
		return the number of the input node
		@return in
	*/
	public int getInput()
	{
		return this.in;
	}

	/**
		returns the number of the output node
		@return out
	*/
	public int getOutput()
	{
		return this.out;
	}

	/**
		returns the weigth of the connection
		@return weigth
	*/
	public double getWeigth()
	{
		return this.weigth;
	}

	/**
		returns the enable state of the connection
		@return enbaleBit
	*/
	public boolean getEnableBit()
	{
		return this.enableBit;
	}

	/**
		returns the innovation number of the connection
		@return innovNum
	*/
	public int getInnovNum()
	{
		return this.innov;
	}

	/**
		returns a copy of the conenction gene
		@return clone
	*/
	public ConnectionGene copy()
	{
		ConnectionGene clone = new ConnectionGene(this.in, this.out, this.weigth, this.enableBit, this.innov);
		return clone;
	}

	/**
		A method that that returns a string representatio of the connection gene
		@return strCG
	*/
	public String toString()
	{
		String en = this.enableBit? "True" : "False";
		String strCG = String.format("\nIn: %s\nOut: %s\nWeigth: %4.4f\nEnabled: %s\nInnovNum: %d\n",this.in, this.out, this.weigth, en, this.innov);
		return strCG;

	}
}