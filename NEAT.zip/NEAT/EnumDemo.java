public class EnumDemo
{
	enum Types
	{
		SENSOR,
		HIDDEN,
		OUTPUT
	}	
	public static void main(String[] args) 
	{


		Types nodeType = Types.SENSOR;

		System.out.println(nodeType); 
		if(nodeType == Types.SENSOR){ System.out.println("Input");}
	}
}