/**
	A class that holds a pair of connection genes
*/
public class CGPair
{
	private ConnectionGene cg1;
	private ConnectionGene cg2;

	public CGPair(ConnectionGene cg1, ConnectionGene cg2)
	{
		this.cg1 = cg1;
		this.cg2 = cg2;
	}

	/**
		returns the first connection gene
		@return cg1
	*/
	public ConnectionGene getFirstCG()
	{
		return this.cg1;
	}

	/**
		returns the second connection gene
		@return cg2
	*/
	public ConnectionGene getSecondCG()
	{
		return this.cg2;
	}
}