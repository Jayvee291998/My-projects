import java.util.ArrayList;

public class GenomeDemo
{
	public static void main(String[] args) 
	{
		ArrayList<NodeGene> nodeGenes = new ArrayList<NodeGene>();
		ArrayList<ConnectionGene> connectionGenes = new ArrayList<ConnectionGene>();

	

		nodeGenes.add(new NodeGene(1, NodeTypes.SENSOR));
		nodeGenes.add(new NodeGene(2, NodeTypes.SENSOR));
		nodeGenes.add(new NodeGene(3, NodeTypes.SENSOR));
		nodeGenes.add(new NodeGene(4, NodeTypes.OUTPUT));
		nodeGenes.add(new NodeGene(5, NodeTypes.HIDDEN));

		connectionGenes.add(new ConnectionGene(1, 4, 0.7, true, 1));
		connectionGenes.add(new ConnectionGene(2, 4, 0.5, false, 2));
		connectionGenes.add(new ConnectionGene(3, 4, 0.5, true, 3));
		connectionGenes.add(new ConnectionGene(2, 5, 0.2, true, 4));
		connectionGenes.add(new ConnectionGene(5, 4, 0.4, true, 5));
		connectionGenes.add(new ConnectionGene(1, 5, 0.6, true, 6));
		connectionGenes.add(new ConnectionGene(4, 5, 0.6, true, 11));

		Genome genome1 = new Genome(nodeGenes, connectionGenes, 11, 5);

		ArrayList<NodeGene> nodeGenes2 = new ArrayList<NodeGene>();
		ArrayList<ConnectionGene> connectionGenes2 = new ArrayList<ConnectionGene>();

		nodeGenes2.add(new NodeGene(1, NodeTypes.OUTPUT));
		nodeGenes2.add(new NodeGene(2, NodeTypes.OUTPUT));
		nodeGenes2.add(new NodeGene(3, NodeTypes.OUTPUT));
		nodeGenes2.add(new NodeGene(6, NodeTypes.HIDDEN));

		connectionGenes2.add(new ConnectionGene(1, 9, 0.123, false, 1));
		connectionGenes2.add(new ConnectionGene(2, 6, 0.124, false, 2));
		connectionGenes2.add(new ConnectionGene(3, 7, 0.125, false, 3));
		connectionGenes2.add(new ConnectionGene(6, 5, 0.126, false, 11));
		Genome genome2 = new Genome(nodeGenes2, connectionGenes2, 4, 6);

		//ArrayList<ConnectionGene>

		//System.out.println(genome2);

		ArrayList<CGPair> matchConGene = Genome.getMatchingConGenes(connectionGenes, connectionGenes2);

		for(CGPair cg : matchConGene)
		{
			System.out.println(cg.getFirstCG());
			System.out.println(cg.getSecondCG());
			System.out.println("------------------------------------------------------");
		}

		/**System.out.println(genome);
		//genome.findUnconNodes();
		//genome.addConnection();
		//genome.addConnection();
		

		genome.addNode();
		genome.addNode();


		ArrayList<NodePair> pairs = genome.getUnconNodes();
		//genome.addConnection();
		System.out.println(genome);

		for(NodePair pair : pairs)
		{
			System.out.println(pair);
		}*/


		/**for(int i = 0; i < nodeGenes.size(); i++)
		{
			for(int j = 0; j < nodeGenes.size(); j++)
			{
				System.out.println("Node " + (i+1) + " and Node " + (j+1) + " : " + genome.isConnected(nodeGenes.get(i), nodeGenes.get(j)));
			}
		}*/
		//System.out.println(genome.isConnected(nodeGenes.get(3), nodeGenes.get(1)));
	}
}