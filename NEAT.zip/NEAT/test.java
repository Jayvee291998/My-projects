import java.util.ArrayList;

public class test 
{
	public static void main(String[] args) 
	{
		/** checking the copy function ConnectionGene
		ConnectionGene cg1 = new ConnectionGene(1, 5, 0.321, true, 1);
		ConnectionGene cg1Clone = cg1.copy();
		cg1Clone.setEnbl(false);

		System.out.println(cg1);
		System.out.println(cg1Clone);*/

		//testing the pairing of matching gene
		//the contents of these arrays are incresing e.g. array[n] < array[n+1]
		int[] array1 = {1,2,3,4,5,6,11};//new int[20];
		int[] array2 = {1,2,3,11};//new  int[10];

		//genRandomContents(array1, 5);
		//genRandomContents(array2, 10);


		print(array1);
		print(array2);

		ArrayList<Integer> intersection = getIntersection(array1, array2);

		System.out.println("Number of same elements: " + intersection.size());

		System.out.println();
		for(int i : intersection)
		{
			System.out.print(i + " ");
		}
		System.out.println();
	}

	/**
		find all the elements in array1 that is also an element of array2
		@param array1
		@param array2
		@return an array of all the elements that is both present in the two arrays
	*/
	public static ArrayList<Integer> getIntersection(int[] array1, int[] array2)
	{
		ArrayList<Integer> intersetionArray = new ArrayList<Integer>();
		int counter = 0;
		for(int i = 0; i < array1.length; i++)
		{
			int a1 = array1[i];
			for(int j = counter; j < array2.length; j++)
			{
				int a2 = array2[j];
				//checks if the two elements are equal
				if(a1 == a2)
				{
					intersetionArray.add(a1); //put the element on the arraylist
					counter++; //increment the counter because the next element is higher than a1[j] so they cant possibly be be equal
					break;
				}
				else if(a1 < a2)
				{
					counter--; //decrement the counter since a2[j] > a1[j] which means theres a possiblity a2[j] is also bigger than a1[j+1]
					break;
				}
				else
				{
					counter++;	
				}
			}
			//check wether j already reach the end of array2
			if(counter > array2.length - 1){ break;}
		}
		return intersetionArray;
	}

	/**
		generates random contents of the array in increasing order with a set interval
		@param array
		@param interval
	*/
	public static void genRandomContents(int[] array, int interval)
	{
		array[0] = 0;
		//generate the contents of array
		for(int i = 1; i < array.length; i++)
		{
			int con = (int)((Math.random() * ((array[i-1] + interval) - array[i-1]) + array[i - 1] + 1));
			array[i] = con;
		}
	}

	/**
		prints an array
		@param array
	*/
	public static void print(int[] array)
	{
		System.out.println();
		for(int con : array)
		{
			System.out.print(con + " ");
		}
		System.out.println();
	}
}