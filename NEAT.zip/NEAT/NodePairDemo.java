public class NodePairDemo
{
	public static void main(String[] args) 
	{
		NodeGene node1 = new NodeGene(1, NodeTypes.SENSOR);
		NodeGene node2 = new NodeGene(2, NodeTypes.HIDDEN);

		System.out.println(node1.equal(node1));
		NodePair pair1 = new NodePair(node1, node2);
		System.out.println(pair1);
	}
}