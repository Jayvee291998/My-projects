public class NodeGene
{
	private final int nodeNum; //the number of the node
	private NodeTypes type; //the type of node
	public NodeGene(int nodeNum, NodeTypes type)
	{
		this.nodeNum = nodeNum;
		this.type = type;
	}

	/**
		returns the bodeNum of the current node
		@return nodeNum
	*/
	public int getNodeNum()
	{
		return this.nodeNum;
	}

	/**
		returns the node type of the node
		@return nodetype
	*/
	public NodeTypes getNodeType()
	{
		return this.type;
	}

	/**
		returns a copy of the node gene
		@return copy of the node gene
	*/
	public NodeGene copy()
	{
		NodeGene copy = new NodeGene(this.nodeNum, this.type);
		return copy;
	}

	/**
		a method that returns the string representaion of the node gene
		@return ng
	*/
	public String toString()
	{
		String ng = String.format("\nNode: %3d\nType: %6s\n", this.nodeNum, this.type);
		return ng;
	}

	/**
		determines if the current node is equal to a given node
		a node is equal to another node if there node num and node type are the same
		@param otherNode
	*/
	public boolean equal(NodeGene otherGene)
	{
		return (this.nodeNum == otherGene.getNodeNum() && this.type == otherGene.getNodeType());
	}
}