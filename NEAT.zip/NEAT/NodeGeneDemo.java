public class NodeGeneDemo
{
	public static void main(String[] args) 
	{
		NodeGene ng = new NodeGene(1, NodeTypes.SENSOR);

		System.out.println(ng);
	}
}