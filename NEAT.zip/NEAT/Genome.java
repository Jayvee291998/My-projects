import java.util.ArrayList;

public class Genome
{
	private ArrayList<NodeGene> nodeGenes;
	private ArrayList<ConnectionGene> connectionGenes;
	private int innovCount; //the current count on how many innovation occured
	private int nodeCount; //the current count on how many node genes has occured
	private ArrayList<NodePair> unconnectedPairs; // list of unconnected node pairs
	/**
		constructs the genome using the provided nodegenes and connection genes
		@param nodeGenes 
		@param connectionGenes
	*/
	public Genome(ArrayList<NodeGene> nodeGenes, ArrayList<ConnectionGene> connectionGenes, int innovCount, int nodeCount)
	{
		this.nodeGenes = new ArrayList<NodeGene>(nodeGenes);
		this.connectionGenes = new ArrayList<ConnectionGene>(connectionGenes);
		this.innovCount = innovCount;
		this.nodeCount = nodeCount;
		this.unconnectedPairs = new ArrayList<NodePair>();
		findUnconNodes(); //initialize the list of unconnected nodes
	}

	/**
		The Add connection method adds a new connection on a random pair of node genes thats not connected together
	*/
	public void addConnection()
	{
		//check if the unconnected pairs are not empty
		if(this.unconnectedPairs.size() > 0)
		{
			//pick a random node pair in the unconected nodes list
			int randomIndex = (int)(Math.random() * (this.unconnectedPairs.size() - 1));
			NodePair randomNodePair = this.unconnectedPairs.get(randomIndex);
			NodeGene randomNode1 = randomNodePair.getFirstNode();
			NodeGene randomNode2 = randomNodePair.getSecondNode();
			//remove the chosen node pair because theyre about to be connected
			this.unconnectedPairs.remove(randomIndex);

			//incerement the innovation count, because we added a new connection gene
			this.innovCount++;

			//if they are not connected create a a new connection gene connecting those two node gene
			int in = randomNode1.getNodeNum();
			int out = randomNode2.getNodeNum();
			double weigth = Math.random();
			boolean enable = Math.random() >= 0.5? true : false;
			int innov = this.innovCount;
			ConnectionGene newCG = new ConnectionGene(in, out, weigth, enable, innov);
			//add the new gene to the arraylist
			this.connectionGenes.add(newCG);
		}
	}

	/**
		adds a new node in the node gene list
	*/
	public void addNode()
	{
		//pick a random conenction from the connection gene list
		int randomIndex = (int)(Math.random() * (this.connectionGenes.size() - 1));
		ConnectionGene randonConnectionGene = this.connectionGenes.get(randomIndex);
		randonConnectionGene.setEnbl(false); //disable the random connection
		//get all the necessary information from the random connection gene
		double randonCGWeigth = randonConnectionGene.getWeigth();
		int randomCGIn = randonConnectionGene.getInput();
		int randomCGOut = randonConnectionGene.getOutput();

		//create the new node and increment the node count 
		this.nodeCount++;
		NodeGene newNode = new NodeGene(this.nodeCount, NodeTypes.HIDDEN);

		//add the new node to the node list
		this.nodeGenes.add(newNode);

		//create the two new connections
		this.innovCount++; //increase the innov count because a new connection is created
		ConnectionGene newCG1 = new ConnectionGene(randomCGIn, newNode.getNodeNum(), 1, true, this.innovCount);
		this.innovCount++;
		ConnectionGene newCG2 = new ConnectionGene(newNode.getNodeNum(), randomCGOut, randonCGWeigth, true, this.innovCount);

		//add the two new connection gene the list
		this.connectionGenes.add(newCG1);
		this.connectionGenes.add(newCG2);

		//update the list of unconnected nodes beacuase new node has been added
		NodeGene n1 = getNodeGene(randomCGIn);
		NodeGene n2 = getNodeGene(randomCGOut);
		NodePair newUnconNode1 = new NodePair(n2, newNode);
		NodePair newUnconNode2 = new NodePair(newNode, n1);
		this.unconnectedPairs.add(newUnconNode1);
		this.unconnectedPairs.add(newUnconNode2);
	}

	/**
		the method that perform the cross over on two genes
		@param genome1
		@param genome2
		@return newGenome
	
	public static Genome crossOver(Genome genome1, Genome genome2)
	{
		ArrayList<ConnectionGene> newConnectionGenes = new ArrayList<ConnectionGene>();
		ArrayList<ConnectionGene> genome1ConnectionGenes = new ArrayList<ConnectionGene>(genome1.getConnectionGenes());
		ArrayList<ConnectionGene> genome2ConnectionGenes = new ArrayList<ConnectionGene>(genome2.getConnectionGenes());
		for(int i = 0; i < genome1ConnectionGenes; i++)
		{
			for(int j = 0; j < )
		}

	}*/

	

	/**
		find all the matching connection gene then chose 1 randomly then add it to the list of matching gene
		@param connectionGenes1
		@param connectionGenes2
		@return a list of matching conenction gene
	*/
	public static ArrayList<CGPair> getMatchingConGenes(ArrayList<ConnectionGene> connectionGenes1, ArrayList<ConnectionGene> connectionGenes2)
	{
		ArrayList<CGPair> matchingConGenes = new ArrayList<CGPair>();

		ArrayList<Integer> connectionGenes1Innovs = Genome.getAllInnov(connectionGenes1);
		ArrayList<Integer> connectionGenes2Innovs = Genome.getAllInnov(connectionGenes2);

		System.out.println(connectionGenes1Innovs);
		System.out.println(connectionGenes2Innovs);

		int counter = 0;
		for(int i = 0; i < connectionGenes1Innovs.size(); i++)
		{
			int a1 = connectionGenes1Innovs.get(i);
			for(int j = counter; j < connectionGenes2Innovs.size(); j++)
			{
				int a2 = connectionGenes2Innovs.get(j);
				//checks if the two elements are equal
				if(a1 == a2)
				{
					matchingConGenes.add(new CGPair(connectionGenes1.get(i), connectionGenes2.get(j)));
					System.out.println(a2);
					counter++; //increment the counter because the next element is higher than a1[j] so they cant possibly be be equal
					break;
				}
				else if(a1 < a2)
				{
					counter--; //decrement the counter since a2[j] > a1[j] which means theres a possiblity a2[j] is also bigger than a1[j+1]
					break;
				}
				else
				{
					counter++;	
				}
			}
			//check wether j already reach the end of array2
			if(counter > connectionGenes2.size() - 1){ break;}
		}
		return matchingConGenes;


	}

	/**
		returns a list of innovation number from a given connection genes list
		@param cGList
		@return innovList
	*/
	public static ArrayList<Integer> getAllInnov(ArrayList<ConnectionGene> connectionGenes)
	{
		ArrayList<Integer> allInnovNum = new ArrayList<Integer>();

		for(ConnectionGene cg : connectionGenes)
		{
			int innov = cg.getInnovNum();
			allInnovNum.add(innov);
		}
		return allInnovNum;
	}

	/**
		find all unconnected node and store them in an array of nodePairs
	*/
	public void findUnconNodes()
	{
		for(int i = 0; i < this.nodeGenes.size(); i++)
		{
			NodeGene node1 = this.nodeGenes.get(i);
			for(int j = 0; j < this.nodeGenes.size(); j++)
			{
				NodeGene node2 = this.nodeGenes.get(j);
				//check wether the nodes are not connected,
				// that the out node (node2) is not a sensor because a sensor node 
				//cannot receive data other the than the input and that node1 is not equal to node 2
				if(!isConnected(node1, node2) && node2.getNodeType() != NodeTypes.SENSOR && !node1.equal(node2))
				{
					this.unconnectedPairs.add(new NodePair(node1, node2));
				}
			}
		}
	}

	/**
		returns the node genes
		@return nodeGenes
	*/
	public ArrayList<NodeGene> getNodeGenes()
	{
		return this.nodeGenes;
	}

	/**
		returns the connection genes list
		@return connectionGenes
	*/
	public ArrayList<ConnectionGene> getConnectionGenes()
	{
		return this.connectionGenes;
	}

	/**
		finds a specific node by nodenum then return it
		@return node
	*/
	public NodeGene getNodeGene(int nodeNum)
	{
		NodeGene node = new NodeGene(0,NodeTypes.HIDDEN);
		for(NodeGene n : this.nodeGenes)
		{
			int nN = n.getNodeNum();
			if(nN == nodeNum)
			{
				node = n;
				break;
			}
		}
		return node;
	}

	/**
		return the unconnected nodes list
		@return unonnected nodes 
	*/
	public ArrayList<NodePair> getUnconNodes()
	{
		return this.unconnectedPairs;
	}

	/**
		Checks wether two input nodes are connected
		@param node1
		@param node2
		@return true if they are connected
	*/
	public boolean isConnected(NodeGene node1, NodeGene node2)
	{
		boolean isConnected = false;
		int nodeNum1 = node1.getNodeNum();
		int nodeNum2 = node2.getNodeNum();

		//loop through the list of connection genes
		//then get the in and out of each individual connection gene
		//if the both node num is equal to to either in and out of of the current
		//connection gene then those node genes are connected
		for(ConnectionGene cg : this.connectionGenes)
		{
			int in = cg.getInput();
			int out = cg.getOutput();

			if((nodeNum1 == in && nodeNum2 == out) || (nodeNum2 == in && nodeNum1 == out))
			{
				isConnected = true;
				break;
			}
		}
		return isConnected;
	}

	/**
		A method that returns the innovation count of the genome
		@return innovCount
	*/
	public int getInnovCount()
	{
		return this.innovCount;
	}

	/**
		A method that returns the string representation of the genome
		@return genomeStr
	*/
	public String toString()
	{
		String genomeStr = String.format("\nNode Genes:\n");
		for(NodeGene ng : this.nodeGenes)
		{
			genomeStr += ng.toString();
		}
		genomeStr += String.format("\nConnection Genes:\n");
		for(ConnectionGene cg : this.connectionGenes)
		{
			genomeStr += cg.toString();
		}

		return genomeStr;
	}

}