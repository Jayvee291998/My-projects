enum NodeTypes
{
	SENSOR,
	HIDDEN,
	OUTPUT
}