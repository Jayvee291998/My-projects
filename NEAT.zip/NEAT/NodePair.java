/**
	A class that holds two distinct nodes and represent as a pair
*/

public class NodePair
{
	private NodeGene node1;
	private NodeGene node2;

	public NodePair(NodeGene node1, NodeGene node2)
	{
		this.node1 = node1;
		this.node2 = node2;
	}

	/**
		returns the first node
		@return node1
	*/
	public NodeGene getFirstNode()
	{
		return this.node1;
	}

	/**
		returns the second node
		@return node2
	*/
	public NodeGene getSecondNode()
	{
		return this.node2;
	}

	/**
		returns a string representation of the node pair
		@return str
	*/
	public String toString()
	{
		String str = "Node: " + this.node1.getNodeNum() + " --> " + "Node: " + this.node2.getNodeNum();
		return str;
	}
}