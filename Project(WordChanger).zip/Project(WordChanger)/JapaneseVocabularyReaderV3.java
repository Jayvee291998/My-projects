import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.BufferedReader;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.io.UnsupportedEncodingException;

public class JapaneseVocabularyReaderV3
{
	public static void main(String[] args) throws FileNotFoundException, UnsupportedEncodingException
	{
		String fileLocation = "Files/JapaneseVocabulary.txt";

		HashMap<String, String> dictionary = getDictionary(fileLocation);
		String fileDirectory = "Files/";
		String inputFileName = "LogHorizonVol1";
		String outputFileName = inputFileName + "(coverted)";
		replaceWords(fileDirectory + inputFileName + ".txt", fileDirectory + outputFileName + ".txt", dictionary);
	}

	/**
		accepts a text file , output file, and a dictionary, it would then replace all the words that is present in the dictionary
		to its kanji equivalent, it would then write the modified text to the output file
		@param inputFileName
		@param outputFileName
		@param dictionary
	*/
	public static void replaceWords(String inputFileName, String outputFileName, HashMap<String, String> dictionary) throws FileNotFoundException, UnsupportedEncodingException
	{
		File inputFile = new File(inputFileName);
		Scanner input = new Scanner(inputFile);
		PrintWriter out = new PrintWriter(outputFileName, "utf-8");

		while(input.hasNextLine())
		{
			String line = input.nextLine();
			//Scanner lineScanner = new Scanner(line);
			//lineScanner.useDelimiter("[^A-Za-z]+");
			String[] lineWordArray = line.split(" ");
			String newLine = "";
			for(String curWord : lineWordArray)
			{
				//String curWord = input.next();
				String kanji = dictionary.get(curWord.toLowerCase());
				if(kanji != null)
				{
					newLine += kanji + " ";
				}
				else
				{
					newLine += curWord + " ";
				}
			}
			out.println(newLine);
		}

		input.close();
		out.close();
	}

	/**
		a method that reads a file that conatins a dictionary of english keyword to its kanji representation
		it would then construct a dictionary
		returns a HashMap representing a dis=ctionary that has the key as an english keyword
		and the value is the corresponmding kanji for that keyword
		@param vocabularyFileName
		@return dictionary
	*/
	public static HashMap<String, String> getDictionary(String vocabularyFileName) throws FileNotFoundException, UnsupportedEncodingException
	{;
		File inFile = new File(vocabularyFileName);
		Scanner input = new Scanner(inFile, "utf-8");
		final int numberOfTerm = 2; //the number of term per line

		HashMap<String, String> dictionary = new HashMap<String, String>();

		while(input.hasNextLine()) //loop through the entire file line by line, each line would then be converted to an entry to the dictionary
		{
			String line = input.nextLine();
			String[] termInfo = line.split(","); //get all the words seperated by commas termInfo[0] is the keyword, and termInfo[1] is the kanji
			if(termInfo.length == numberOfTerm) //check if the line from the text file has 3 terms which means its complete
			{
				for(int i = 0; i < termInfo.length; i++)
				{
					termInfo[i] = termInfo[i].trim(); //remove of the whitespaces surrounding the term
				}
				dictionary.put(termInfo[0].toLowerCase(), termInfo[1]);
			}
		}
		input.close();
		return dictionary;
	}
}