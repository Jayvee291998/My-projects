import java.util.Scanner;
import java.io.File;
import java.io.PrintWriter;
import java.io.FileNotFoundException;
import java.util.ArrayList;

public class Test 
{
	public static void main(String[] args) throws FileNotFoundException
	{
		File inputFile = new File("Files/1(copy).txt");
		Scanner in = new Scanner(inputFile);
		PrintWriter	out = new PrintWriter("Files/word_stats.txt");

		//stores all the lines from the text file
		ArrayList<String> lines = new ArrayList<String>();

		//stores all the known words
		ArrayList<Term> terms = new ArrayList<Term>();

		for(Term term : terms)
		{
			System.out.println(term);
		}

		while(in.hasNextLine())
		{
			String line = in.nextLine();
			lines.add(line);
		}

		//loop throught the entire lines list
		for(String line : lines)
		{
			Scanner lineScanner = new Scanner(line); //constructs a scanner object to scan the speific line
			lineScanner.useDelimiter("[^A-Za-z]+"); //only read the words
			while(lineScanner.hasNext()) //scan all the words in the line
			{
				String curWord = lineScanner.next().toLowerCase(); //stores the current word
				//loop throught known terms and see if the current word is in there
				//if so increment the freqeuncy of that term
				//else make a new term object for that word
				boolean foundAMatch = false;
				for(Term term : terms)
				{
					if(term.getTerm().toLowerCase().equals(curWord))
					{
						term.incrementFrequency();
						foundAMatch = true;
						break;
					}
				}
				if(!foundAMatch)
				{
					Term newTerm = new Term(curWord);
					terms.add(newTerm);
				}
				if(terms.size() < 1) //if thw terms list is empty add the first word to it
				{
					Term newTerm = new Term(curWord);
					terms.add(newTerm);
				}

			}
		}

		for(int i = 200; i < 300; i++)
		{
			System.out.println(terms.get(i));
		}

		System.out.println("Total number of words: " + terms.size());

		out.printf("line Count: %5d", lines.size());

		in.close();
		out.close();

		System.out.println(lines.get(14));
	}
}