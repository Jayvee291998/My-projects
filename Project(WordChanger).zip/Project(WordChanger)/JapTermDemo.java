public class JapTermDemo
{
	public static void main(String[] args) 
	{
		String[] termInfo = {"five", "%^%^",	 "itsutsu"};
		JapTerm term = new JapTerm(termInfo);

		term.setHiraganaReading("WONG");
		System.out.println(term);
		System.out.println(term.getKeyWord());
		System.out.println(term.getKanji());
		System.out.println(term.getHiraganaReading());
	}
}