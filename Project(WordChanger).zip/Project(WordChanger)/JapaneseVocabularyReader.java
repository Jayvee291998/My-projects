import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.BufferedReader;
import java.util.Scanner;
import java.util.ArrayList;
import java.io.UnsupportedEncodingException;

public class JapaneseVocabularyReader
{
	public static void main(String[] args) throws FileNotFoundException, UnsupportedEncodingException
	{
		String fileLocation = "Files/JapaneseVocabulary.txt";
		File inFile = new File(fileLocation);
		Scanner input = new Scanner(inFile, "utf-8");
		PrintWriter out = new PrintWriter("out.txt", "utf-8");

		ArrayList<String> lines = new ArrayList<String>();
		ArrayList<JapTerm> japTerms = new ArrayList<JapTerm>();

		while(input.hasNextLine())
		{
			String curLine = input.nextLine();
			lines.add(curLine);
		}
		System.out.println(lines.size());
		for(String line : lines)
		{
			Scanner lineScanner = new Scanner(line);
			while(lineScanner.hasNext())
			{
				String curWord = lineScanner.next();
				out.print(curWord + ", ");
			}
			out.println();
		}	

		input.close();
		out.close();

		String jay = "Jayvee p ascano";
		String[] words = jay.split(" ");
		for(String str : words)
		{
			System.out.println(str);
		}

		System.out.println("Count: " + jay.length());
	}
}