import java.util.Scanner;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.io.File;
import java.io.PrintWriter;
import java.io.FileNotFoundException;
import java.util.ArrayList;

public class Test2
{
	public static void main(String[] args) throws FileNotFoundException
	{
		File inputFile = new File("Files/1(copy).txt");
		Scanner in = new Scanner(inputFile);
		PrintWriter	out = new PrintWriter("Files/word_stats.txt");

		//stores all the lines from the text file
		ArrayList<String> lines = new ArrayList<String>();

		while(in.hasNextLine())
		{
			String line = in.nextLine();
			lines.add(line);
		}
		out.printf("line Count: %5d", lines.size());

		in.close();
		out.close();

		ArrayList<Term> terms = getTerms(lines); //all the terms present in the text file
		Map<String, Integer> reversedTerm = new HashMap<String, Integer>(); //create a hashmap so that we can use the term to get its integer value
		for(int i = 0; i < terms.size(); i++)
		{
			Term t = terms.get(i);
			String word = t.getTerm();
			reversedTerm.put(word, i);
		}

		ArrayList<Integer> encoded = encode(lines, reversedTerm);

		System.out.println(encoded.get(10));
		System.out.println(terms.get(encoded.get(0)));

		/**for(int i = 200; i < 300; i++)
		{
			System.out.println(terms.get(i));
		}

		System.out.println("Total number of words: " + terms.size());*/



		System.out.println(lines.get(14));
	}

	/**
		@param encoded
		@param dictionary
		@param 
	*/

	/**
		Encode a list of lines with integers from our dictionary
		@param lines
		@param dictionary
		@return encoded
	*/
	public static ArrayList<Integer> encode(ArrayList<String> lines, Map<String, Integer> dictionary)
	{
		ArrayList<Integer> encoded = new ArrayList<Integer>();

		for(String line : lines)
		{
			Scanner lineScanner = new Scanner(line);
			lineScanner.useDelimiter("[^A-Za-z]+");
			while(lineScanner.hasNext())
			{
				String curWord = lineScanner.next().toLowerCase();
				encoded.add(dictionary.get(curWord));
			}
			encoded.add(0); //0 means a new line charcter
		}
		return encoded;
	}

	/**
		get all the unique term from all the lines in the lines list
		@param lines
		@return a list of terms
	*/
	public static ArrayList<Term> getTerms(ArrayList<String> lines)
	{
		ArrayList<Term> terms = new ArrayList<Term>();
		terms.add(new Term("\n"));
		//loop throught the entire lines list
		for(String line : lines)
		{
			Scanner lineScanner = new Scanner(line); //constructs a scanner object to scan the speific line
			lineScanner.useDelimiter("[^A-Za-z]+"); //only read the words
			while(lineScanner.hasNext()) //scan all the words in the line
			{
				String curWord = lineScanner.next().toLowerCase(); //stores the current word
				//loop throught known terms and see if the current word is in there
				//if so increment the freqeuncy of that term
				//else make a new term object for that word
				boolean foundAMatch = false;
				for(Term term : terms)
				{
					if(term.getTerm().toLowerCase().equals(curWord))
					{
						term.incrementFrequency();
						foundAMatch = true;
						break;
					}
				}
				if(!foundAMatch)
				{
					Term newTerm = new Term(curWord);
					terms.add(newTerm);
				}
				if(terms.size() < 1) //if thw terms list is empty add the first word to it
				{
					Term newTerm = new Term(curWord);
					terms.add(newTerm);
				}
			}
		}
		return terms;
	}
}