public class TermDemo
{
	public static void main(String[] args) 
	{
		Term word = new Term("Java");

		for(int i = 0; i < 10; i++)
		{
			word.incrementFrequency();
		}

		System.out.print(word);
		
	}
}