/**
	A class that represnts a japanese term with its 
	english keyword, kanji reading, and hiragana reading
*/
public class JapTerm
{
	private String keyWord; //the english keyword
	private String kanji; //the kanji character
	private String hiraganaReading; //the hirgana reading

	public JapTerm()
	{
		this.keyWord = "";
		this.kanji = "";
		this.hiraganaReading = ""; 
	}

	/**
		sets the keyWord
		@param keyWord
	*/
	public void setKeyWord(String keyWord)
	{
		this.keyWord = keyWord;
	}

	/**
		sets the kanji
		@param kanji
	*/
	public void setKanji(String kanji)
	{
		this.kanji = kanji;
	}

	/**
		sets the hiragana reading 
		@param hiraganaReading
	*/
	public void setHiraganaReading(String hiraganaReading)
	{
		this.hiraganaReading = hiraganaReading;
	}

	/**
		returns the keyWord
		@return keyWord
	*/
	public String getKeyWord()
	{
		return keyWord;
	}

	/**
		returns the kanji
		@return kanji
	*/
	public String getKanji()
	{
		return kanji;
	}

	/**
		returns the hiragana reading
		@return hiraganaReading
	*/
	public String getHiraganaReading()
	{
		return hiraganaReading;
	}

	/**
		reutu
	*/
}