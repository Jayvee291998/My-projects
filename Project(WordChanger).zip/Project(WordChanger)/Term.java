/**
	a class that represents a word(term) together with there usage frequency
*/

public class Term 
{
	/**
		contructs the object using 
		@param term the word
	*/
	private String term;
	private int frequency;

	public Term(String term)
	{
		this.term = term;
		this.frequency = 1;
	}

	/**
		increments the frequency by 1
	*/
	public void incrementFrequency()
	{
		this.frequency++;
	}

	/**
		retuurns the term
		@return term
	*/
	public String getTerm()
	{
		return this.term;
	}

	/**
		returns thee frequency
		@return frequency
	*/
	public int getFrequency()
	{
		return this.frequency;
	}

	/**
		returns a string representation of the term
		@return str
	*/
	public String toString()
	{
		String str = String.format("Term: %-10s\tFrequency: %-5d", this.term, this.frequency);
		return str;
	}
}