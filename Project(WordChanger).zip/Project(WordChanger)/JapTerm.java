/**
	A class that represnts a japanese term with its 
	english keyword, kanji reading, and hiragana reading
*/
public class JapTerm
{
	//an array of string of array that holds the three important details
	//its english keyWord, kanji charcter, and hiragana reading
	// term[0] is the keyword
	//term[1] is the kanji character
	//term[2] is the hiragana reading
	private String[] termInfo;

	public JapTerm(String[] termInfo)
	{
		if(termInfo.length == 3)
		{
			this.termInfo = new String[3];
			for(int i = 0; i < termInfo.length; i++)
			{
				this.termInfo[i] = termInfo[i];
			} 
		}
		else
		{
			System.out.println("Failed to create a JapTerm Object");
			return;
		}

	}

	/**
		sets the keyWord
		@param keyWord
	*/
	public void setKeyWord(String keyWord)
	{
		termInfo[0]= keyWord;
	}

	/**
		sets the kanji
		@param kanji
	*/
	public void setKanji(String kanji)
	{
		termInfo[1] = kanji;
	}

	/**
		sets the hiragana reading 
		@param hiraganaReading
	*/
	public void setHiraganaReading(String hiraganaReading)
	{
		termInfo[2] = hiraganaReading;
	}

	/**
		returns the keyWord
		@return keyWord
	*/
	public String getKeyWord()
	{
		return termInfo[0];
	}

	/**
		returns the kanji
		@return kanji
	*/
	public String getKanji()
	{
		return termInfo[1];
	}

	/**
		returns the hiragana reading
		@return hiraganaReading
	*/
	public String getHiraganaReading()
	{
		return termInfo[2];
	}

	/**
		return the string representation of the JapTerm
		@return str
	*/
	public String toString()
	{
		return String.format("Keyword:%10s\tKanji:%10s\tReading:%10s",termInfo[0], termInfo[1], termInfo[2]);
	}
}