import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.BufferedReader;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.io.UnsupportedEncodingException;

public class JapaneseVocabularyReaderV2
{
	public static void main(String[] args) throws FileNotFoundException, UnsupportedEncodingException
	{
		String fileLocation = "Files/JapaneseVocabulary.txt";
		File inFile = new File(fileLocation);
		Scanner input = new Scanner(inFile, "utf-8");
		PrintWriter out = new PrintWriter("out.txt", "utf-8");

		HashMap<String, JapTerm> dictionary = new HashMap<String, JapTerm>();

		while(input.hasNextLine())
		{
			String line = input.nextLine();
			String[] termInfo = line.split(","); //get all the words seperated by commas
			if(termInfo.length == 3) //check if the line from the text file has 3 terms which means its complete
			{
				for(int i = 0; i < termInfo.length; i++)
				{
					termInfo[i] = termInfo[i].trim(); //remove of the whitespaces surrounding the term
				}
				JapTerm newJapTerm = new JapTerm(termInfo);
				dictionary.put(newJapTerm.getKeyWord(), newJapTerm);
			}
		}

		String sampleString = "1 for that one";
		String[] sampleStringArray = sampleString.split(" ");
		String newStr = "";
		for(String word : sampleStringArray)
		{
			if(dictionary.get(word) != null)
			{
				JapTerm jp = dictionary.get(word);
				newStr += jp.getKanji() + " ";
			}
			else
			{
				newStr += word + " ";
			}
		}
		out.println(newStr);
		System.out.println(newStr);

		/**String jay = "		       jayve," + "	 	 	pa," + "	       jas,";
		String[] words = jay.split(",");
		for(String str : words)
		{
			System.out.print(str.trim() + " ");
		}

		System.out.println("Count: " + jay.length());*/

		input.close();
		out.close();
	}
}