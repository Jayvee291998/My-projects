import java.util.LinkedList;
/**
	a class that represents the important data about a vertex
*/
public class VertexData
{
	public final int INFINITY = 2147483647; //the number used to represent infinity
	public int lowestCost = INFINITY;
	public LinkedList<Integer> path = new LinkedList<Integer>();
}