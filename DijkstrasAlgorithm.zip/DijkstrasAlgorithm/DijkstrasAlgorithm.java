 import java.util.ArrayList;
 import java.util.Arrays;
 import java.util.Set;
 import java.util.HashSet;
 import java.util.Iterator;
 import java.util.LinkedList;
 import java.util.ListIterator;

 public class DijkstrasAlgorithm
 {
 	public static void main(String[] args) 
 	{
 		Graph graph = new Graph(8);

 		graph.addUndirectedEdge(0, 1, 2);
 		graph.addUndirectedEdge(0, 2, 8);
 		graph.addUndirectedEdge(0, 3, 4);

 		graph.addUndirectedEdge(1, 2, 3);

 		graph.addUndirectedEdge(2, 3, 3);
 		graph.addUndirectedEdge(2, 4, 3);

 		graph.addUndirectedEdge(3, 4, 4);
 		graph.addUndirectedEdge(3, 5, 10);
 		graph.addUndirectedEdge(3, 6, 5);

 		graph.addUndirectedEdge(4, 5, 5);

 		graph.addUndirectedEdge(5, 7, 2);
 		graph.addUndirectedEdge(5, 6, 4);

 		graph.addUndirectedEdge(6, 7, 5);

 		System.out.println(graph);

 		int startingVertex = 0;

 		VertexData[] vertexData = pathFinder(startingVertex, graph);	


 		String[] legend = {"Pendleton", "Pierre", "Pueblo", "Phoenix", "Peoria", "Pittsburgh", "Pensacola", "Princeton"};

 		traverseAllDestinations(vertexData, legend);

 	}
 	/**
 		traverse all the possible destination
 		@param verData
 		@param legend
 	*/
 	public static void traverseAllDestinations(VertexData[] verData, String[] legend)
 	{
 		int startingVertex = verData[0].path.getFirst();
 		for(int i = 0; i < verData.length; i++)
 		{
 			if(i!= startingVertex)
 			{
	  			System.out.println("From " + legend[startingVertex] + " to " + legend[i]);
	 			traversePath(verData[i], legend);
	 			System.out.println();	
 			}

 		}
 	}

 	/**
 		traverse the path from startingIndex to the endingVertex from the path data
 		@param endingVertex
 		@param pathData
 	*/
 	public static void traversePath(VertexData data, String[] legend)
 	{
 		ListIterator<Integer> iter = data.path.listIterator();
 		int index = 0;
 		while(iter.hasNext()) 		
 		{
 			int curVertex = iter.next();
 			if(iter.hasNext())
 			{
 				System.out.print(legend[curVertex] + " -> ");
 			}
 			else
 			{
 				System.out.print(legend[curVertex]);
 			}
 			
 		}
 		System.out.println();
 		System.out.println("Cost: " + data.lowestCost);
 	}

 	/**
 		a method that implements dijkstras algorithm
 		accepts a starting vertex then calculate the cheapest path tp each and every vertices in the graph
 		@param startingVertex
 		@param graph
 	*/
 	public static VertexData[] pathFinder(int startingVertex, Graph graph)
 	{
 		int numVertices = graph.getNumVertices();
 		final int INFINITY = graph.getInf(); //the number used to represent infinity
 		final int UNDEFINEDVERTEX = -1; //represents that the vertex does not exist on the graph
 		Set<Integer> unvisited = new HashSet<Integer>(); //the umvisited vertices
 		for(int i = 0; i < numVertices; i++){ unvisited.add(i);} //in the beginning all vertices are unvisited

 		VertexData[] vertexData = new VertexData[numVertices];
 		for(int i = 0; i < vertexData.length; i++)
 		{
 			vertexData[i] = new VertexData();
 		}
  		vertexData[startingVertex].lowestCost = 0;
  		vertexData[startingVertex].path.add(startingVertex);

 		int currentVertex = startingVertex;

 		while(unvisited.size() > 0)//for(int i = 0; i < 10; i++)//	//
 		{
 			//System.out.println("Current Vertex: " + currentVertex + " Unvisited Size: " + unvisited.size());
 			ArrayList<Integer> adjacentVertices = graph.getAdjacentVertices(currentVertex);
 			//look at all the adjacent vertices of the currentVertex
 			for(int vertex : adjacentVertices)
 			{
 				int distance = vertexData[currentVertex].lowestCost + graph.getWeight(currentVertex, vertex);
 				if(distance < vertexData[vertex].lowestCost)
 				{ 
 					vertexData[vertex].lowestCost = distance; 
 					vertexData[vertex].path = new LinkedList<Integer>(vertexData[currentVertex].path);
 					vertexData[vertex].path.add(vertex);
 				}//checks if the currentDistance is less than the shortest path in the vertex
 			}
 			unvisited.remove(currentVertex); //removes the current vertex to the list of unvisited vertices

 			int nextVertex = UNDEFINEDVERTEX; 
 			int nextVertexValue = INFINITY;
 			//find an unvisited vertex that has the lowest path cost
 			for(int vertex : unvisited)
 			{
 				if(vertexData[vertex].lowestCost < nextVertexValue){ nextVertexValue = vertexData[vertex].lowestCost; nextVertex = vertex;}
 			}
 			currentVertex = nextVertex;
 			
 		}
 	 	return vertexData;
 	}
 }