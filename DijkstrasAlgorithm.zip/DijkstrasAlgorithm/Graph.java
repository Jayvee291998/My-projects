import java.util.ArrayList;
/**
	represents a graph
	a vertex is represented by the array that contains all of its connection to all the vertices
	a vertex is just the row index of the adjacency matrix
	an edge  to vertex i to vertex j is adm[i][j]
*/
public class Graph
{
	private int numVertices; //the number of vertices present in the graph
	private int[][] adjacencyMatrix; //the matrix that represents the vertices and its connections
	private static final int INFINITY = 2147483647; //the consrant that represents that two vertices are not connected
	/**
		creates the constructor, the constructor is supplied by the number of vertices in the graph
		and initiliaze the adjacencyMatrix to have empty edges
		@param n
	*/
	public Graph(int n)
	{
		numVertices = n;
		adjacencyMatrix = new int[numVertices][numVertices]; //initialize the 2d array 
		for(int i = 0; i < adjacencyMatrix.length; i++) //initialize the adjacency matrix to have no edges between the vertices
		{
			for(int j = 0; j < adjacencyMatrix[0].length; j++)
			{
				adjacencyMatrix[i][j] = INFINITY;
			}
		}
	}

	/**
		return the number of vertices of the graph
		@return numVertices
	*/
	public int getNumVertices()
	{
		return numVertices;
	}

	/**
		returns the edge from i to j
		@param i from vertex i
		@param j to vertex j
		@return the weigth the adjacency matrix
	*/
	public int getWeight(int i, int j)
	{
		int weight = INFINITY;
		if(isVertexOnGraph(i) && isVertexOnGraph(j))
		{
			weight = adjacencyMatrix[i][j];
		}
		else
		{
			System.out.println("The vertex " + i + " or " + j + " is not on the graph.");
		}

		return weight;
	}

	/**
		return the values that is used to represent infinity
		@return inf
	*/
	public static int getInf()
	{
		return INFINITY;
	}
	/**
		get the adjacent vertex to the given vertex
		@param vertex
		@return an array of all the vertex that is adjacent to the given vertex
	*/
	public ArrayList<Integer> getAdjacentVertices(int vertex)
	{
		ArrayList<Integer> adjacentVertices = new ArrayList<Integer>();
		if(isVertexOnGraph(vertex))
		{
			for(int i = 0; i < adjacencyMatrix[vertex].length; i++)
			{
				if(adjacencyMatrix[vertex][i] != INFINITY){ adjacentVertices.add(i);}
			}
		}
		return adjacentVertices;
	}
	/**
		adds a directed edge from vertex i to vertex j with a given weigth
		@param i from
		@param j to
		@param w the weigth of the edge
	*/
	public void addEdge(int i, int j, int w)
	{
		if(isVertexOnGraph(i) && isVertexOnGraph(j))
		{
			adjacencyMatrix[i][j] = w;
		}
		else
		{
			System.out.println("The vertex " + i + " or " + j + " is not on the graph.");
		}
	}

	/**
		adds an undirected edge between vertex i and j
		@param v1
		@param v2
	*/
	public void addUndirectedEdge(int v1, int v2, int weigth)
	{
		if(isVertexOnGraph(v1) && isVertexOnGraph(v2))
		{
			adjacencyMatrix[v1][v2] = weigth;
			adjacencyMatrix[v2][v1] = weigth;
		}
	}

	/**
		checks wether a given vertex is on the graph
		@param i
		@return true if the vertex is on the graph
	*/
	private boolean isVertexOnGraph(int i)
	{
		boolean result = false;
		if(i >= 0 && i < numVertices)
		{
			result = true;
		}
		return result;
	}

	/**
		returns the string representation of the graph
		by returning all the vertices that the current vertex is has an edge with
		@return str
	*/
	public String toString()
	{
		String str = "";
		for(int i = 0; i < adjacencyMatrix.length; i++)
		{
			String curVertexEdgeStr = "vertex " + i + " --> ";
			for(int j = 0; j < adjacencyMatrix[0].length; j++)
			{
				if(adjacencyMatrix[i][j] != INFINITY){ curVertexEdgeStr += j + ", ";}
			}
			str += String.format("%s\n", curVertexEdgeStr);
		}
		return str;
	}
}